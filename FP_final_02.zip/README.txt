Group individual reflections appended at the end of the developmental document. Contents page is clickable.

Best viewed in Chrome in large browser window.